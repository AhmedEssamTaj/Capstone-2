package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Post;
import com.example.capstone2.Repository.NeighborhoodRepository;
import com.example.capstone2.Repository.PostRepository;
import com.example.capstone2.Repository.UserAccountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
public class PostService {
    private final PostRepository postRepository;
    private final NeighborhoodRepository neighborhoodRepository;
    private final UserAccountRepository userAccountRepository;

    // get all posts
    public List<Post> getAllPosts(){
        return postRepository.findAll();
    }

    // add a post
    public void addPost(Post post){
        if(!userAccountRepository.existsUserAccountById(post.getUserId())){
            throw new ApiException("No user with this id exists");
        }
        if (!neighborhoodRepository.existsNeighborhoodById(post.getNeighborhoodId())) {
            throw new ApiException("No neighborhood with this id exists");
        }
        postRepository.save(post);
    }

    // update a post
    public void updatePost(Integer id,Post post){

        Post oldPost = postRepository.findPostById(id);
        if (oldPost == null) {
            throw new ApiException("No post with this id exists");
        }
        if (!userAccountRepository.existsUserAccountById(post.getUserId())){
            throw new ApiException("No user with this id exists");
        }
        if (!neighborhoodRepository.existsNeighborhoodById(post.getNeighborhoodId())) {
            throw new ApiException("No neighborhood with this id exists");
        }
        oldPost.setUserId(post.getUserId());
        oldPost.setTitle(post.getTitle());
        oldPost.setDescription(post.getDescription());
        oldPost.setNeighborhoodId(post.getNeighborhoodId());
        oldPost.setType(post.getType());
        oldPost.setExpiresAt(post.getExpiresAt());
        postRepository.save(oldPost);

    }

    // delete a post
    public void deletePost(Integer id){
        Post post = postRepository.findPostById(id);
        if (post == null) {
            throw new ApiException("No post with this id exists");
        }
        postRepository.delete(post);
    }

    // get all posts by user
    public List<Post> getPostsByUserId(Integer userId){
        List<Post> posts = postRepository.findPostByUserId(userId);
        if (posts.isEmpty()) {
            throw new ApiException("No posts with this user id exists");
        }
        return posts;
    }

    // method to get all the newest posts in the neighborhood
    public List<Post> getNewestPostsByNeighborhoodId(Integer neighborhoodId){
        List<Post> posts = postRepository.findPostsByNeighborhoodOrderByCreatedAt(neighborhoodId);
        if (posts.isEmpty()) {
            throw new ApiException("No posts with this neighborhood id exists");
        }
        return posts;


    }

    // method to search through the posts by title
    public List<Post> searchPostsByTitle(Integer neighborhoodId,String title){
        List<Post> posts = postRepository.findPostByNeighborhoodIdAndTitleContainsIgnoreCase(neighborhoodId, title);
        if (posts.isEmpty()) {
            throw new ApiException("No posts in this neighborhood with this title");
        }
        return posts;
    }

}
