package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Neighborhood;
import com.example.capstone2.Model.Post;
import com.example.capstone2.Service.PostService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/post")
@AllArgsConstructor
public class PostController {

    private final PostService postService;

    @GetMapping("/get-all")
    public ResponseEntity getAllPosts() {
        return ResponseEntity.status(200).body(postService.getAllPosts());
    }

    @PostMapping("/add")
    public ResponseEntity addPost(@RequestBody @Valid Post post, Errors errors) {

        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        postService.addPost(post);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added post"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updatePost(@PathVariable Integer id,@RequestBody @Valid Post post, Errors errors) {
        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        postService.updatePost(id, post);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated post"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deletePost(@PathVariable Integer id) {
        postService.deletePost(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted post"));
    }

    // endpoint to get posts by user
    @GetMapping("/get-user/{userId}")
    public ResponseEntity getPostByUserId(@PathVariable Integer userId) {
        return ResponseEntity.status(200).body(postService.getPostsByUserId(userId));
    }

    // endpoint to get the newest posts in the neighborhood --- (9) ---
    @GetMapping("/get-newest/{neighborhoodId}")
    public ResponseEntity getNewestPost(@PathVariable Integer neighborhoodId) {
        return ResponseEntity.status(200).body(postService.getNewestPostsByNeighborhoodId(neighborhoodId));
    }

    // endpoint to search thorough neighborhood posts
    @GetMapping("/search-title/{neighborhoodId}/{title}")
    public ResponseEntity searchPostsByTitle(@PathVariable Integer neighborhoodId, @PathVariable String title) {
        return ResponseEntity.status(200).body(postService.searchPostsByTitle(neighborhoodId, title));
    }

}
