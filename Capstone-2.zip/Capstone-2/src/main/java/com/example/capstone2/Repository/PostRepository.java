package com.example.capstone2.Repository;

import com.example.capstone2.Model.Post;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostRepository extends JpaRepository<Post, Integer> {

    Post findPostById(Integer id);

    boolean existsPostById(Integer id);

    List<Post> findPostByUserId(Integer userId);

    @Query("select p from Post p where p.neighborhoodId = ?1 order by p.createdAt desc ")
    List<Post> findPostsByNeighborhoodOrderByCreatedAt(Integer neighborhoodId);

    List<Post> findPostByNeighborhoodIdAndTitleContainsIgnoreCase(Integer neighborhoodId, String title);

}
