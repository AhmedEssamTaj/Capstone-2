package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.AdminAccount;
import com.example.capstone2.Model.Issue;
import com.example.capstone2.Repository.AdminAccountRepository;
import com.example.capstone2.Repository.IssueRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class AdminAccountService {
    private final AdminAccountRepository adminAccountRepository;
    private final IssueRepository issueRepository;


    // get all admins
    public List<AdminAccount> getAllAdminAccounts(){
        return adminAccountRepository.findAll();
    }

    // add admin account
    public void addAdminAccount(AdminAccount adminAccount){
        adminAccountRepository.save(adminAccount);
    }

    // update admin account
    public void updateAdminAccount(Integer id,AdminAccount adminAccount){
        AdminAccount oldAdminAccount = adminAccountRepository.findAdminAccountById(id);
        if (oldAdminAccount == null){
            throw new ApiException("no such admin account was found");
        }
        oldAdminAccount.setName(adminAccount.getName());
        oldAdminAccount.setPassword(adminAccount.getPassword());
        oldAdminAccount.setEmail(adminAccount.getEmail());
        adminAccountRepository.save(oldAdminAccount);
    }

    // delete admin
    public void deleteAdminAccount(Integer id){
        AdminAccount adminAccount = adminAccountRepository.findAdminAccountById(id);
        if (adminAccount == null){
            throw new ApiException("no such admin account was found");
        }
        adminAccountRepository.delete(adminAccount);
    }



}
