package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.AdminAccount;
import com.example.capstone2.Model.Comment;
import com.example.capstone2.Repository.NeighborhoodRepository;
import com.example.capstone2.Repository.PostRepository;
import com.example.capstone2.Repository.UserAccountRepository;
import com.example.capstone2.Service.CommentService;
import com.example.capstone2.Service.PostService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/comment")
@AllArgsConstructor
public class CommentController {
    private final CommentService commentService;
    private final PostRepository postRepository;
    private final UserAccountRepository userAccountRepository;
    private final NeighborhoodRepository neighborhoodRepository;

    @GetMapping("/get-all")
    public ResponseEntity getAllComments() {
        return ResponseEntity.status(200).body(commentService.getAllComments());
    }

    @PostMapping("/add")
    public ResponseEntity addComment(@RequestBody @Valid Comment comment, Errors errors) {

        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        if (!userAccountRepository.existsUserAccountById(comment.getUserId())) {
            throw new ApiException("user does not exist");
        }
        if (!userAccountRepository.findUserAccountById(comment.getUserId()).getNeighborhoodId().equals(postRepository.findPostById(comment.getPostId()).getNeighborhoodId())) {
            throw new ApiException("user can only comment on posts in his neighborhood");
        }

        commentService.addComment(comment);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added comment"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateComment(@PathVariable Integer id,@RequestBody @Valid Comment comment, Errors errors) {
        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
       commentService.updateComment(id, comment);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated comment"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteComment(@PathVariable Integer id) {
        commentService.deleteComment(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted comment"));
    }

    // endpoint to get all comments of a post
    @GetMapping("/get-post/{postId}")
    public ResponseEntity getAllCommentOnPost(@PathVariable Integer postId){
        return ResponseEntity.status(200).body(commentService.getCommentsByPostId(postId));
    }






}
