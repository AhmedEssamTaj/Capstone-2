package com.example.capstone2.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Check;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "user id must be filled")
    @Column(columnDefinition = "int not null")
    private Integer userId;

    @NotNull(message = "post id must be filled")
    private Integer postId;

    @NotEmpty(message = "comment must be filled")
    @Size(min = 4, max = 75,message = "comment must be between 4 and 75")
    @Column(columnDefinition = "varchar(75) not null")
    @Check(constraints = "CHAR_LENGTH(comment) >= 4")
    private String comment;


}
