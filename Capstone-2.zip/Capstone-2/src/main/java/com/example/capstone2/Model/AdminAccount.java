package com.example.capstone2.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotEmpty(message = "name cannot be empty")
    @Size(min = 4, message = "name length must be at least 4")
    @Column(columnDefinition = "varchar(25) not null unique")
    private String name;

    @NotEmpty(message = "password cannot be empty")
    @Size(min = 8, message = "password length must be at least 8")
    @Column(columnDefinition = "varchar(25) not null")
    private String password;

    @NotEmpty(message = "email cannot be empty")
    @Email(message = "email must follow a valid format")
    @Column(columnDefinition = "varchar(25) not null unique")
    private String email;

}
