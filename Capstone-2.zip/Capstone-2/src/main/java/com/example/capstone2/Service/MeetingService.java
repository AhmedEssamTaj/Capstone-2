package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Issue;
import com.example.capstone2.Model.Meeting;
import com.example.capstone2.Model.MeetingAttendance;
import com.example.capstone2.Model.UserAccount;
import com.example.capstone2.Repository.IssueRepository;
import com.example.capstone2.Repository.MeetingAttendanceRepository;
import com.example.capstone2.Repository.MeetingRepository;
import com.example.capstone2.Repository.UserAccountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class MeetingService {

    private final MeetingRepository meetingRepository;
    private final UserAccountRepository userAccountRepository;
    private final IssueRepository issueRepository;
    private final MeetingAttendanceRepository meetingAttendanceRepository;


    public List<Meeting> getAllMeetings() {
        return meetingRepository.findAll();
    }

    public void addMeeting(Meeting meeting) {
        if (!userAccountRepository.existsUserAccountById(meeting.getUserId())) {
            throw new ApiException("no user with this id was found");
        }
        if (!issueRepository.existsIssueById(meeting.getIssueId())) {
            throw new ApiException("no issue with this id was found");
        }
        if (!issueRepository.findIssueById(meeting.getIssueId()).getCreateMeeting()) {
            throw new ApiException("this issue is not scheduled for a meeting");
        }
        meetingRepository.save(meeting);
    }

    public void updateMeeting(Integer id, Meeting meeting) {
        Meeting oldMeeting = meetingRepository.findMeetingById(id);
        if (oldMeeting == null) {
            throw new ApiException("no meeting with this id was found");
        }
        if (!userAccountRepository.existsUserAccountById(meeting.getUserId())) {
            throw new ApiException("no user with this id was found");
        }
        if (!issueRepository.existsIssueById(meeting.getIssueId())) {
            throw new ApiException("no issue with this id was found");
        }
        if (!issueRepository.findIssueById(meeting.getIssueId()).getCreateMeeting()) {
            throw new ApiException("this issue is not scheduled for a meeting");
        }
        oldMeeting.setIssueId(meeting.getIssueId());
        oldMeeting.setUserId(meeting.getUserId());
        oldMeeting.setMeetingTime(meeting.getMeetingTime());
        oldMeeting.setTitle(meeting.getTitle());
        oldMeeting.setLocation(meeting.getLocation());
        meetingRepository.save(oldMeeting);
    }

    public void deleteMeeting(Integer id) {
        Meeting oldMeeting = meetingRepository.findMeetingById(id);
        if (oldMeeting == null) {
            throw new ApiException("no meeting with this id was found");
        }
        meetingRepository.delete(oldMeeting);
    }

    // method for user to attend a meeting
    public void attendMeeting(Integer meetingId, Integer userId) {

        Meeting meeting = meetingRepository.findMeetingById(meetingId);
        if (meeting == null) {
            throw new ApiException("No such meeting was found");
        }
        if (!userAccountRepository.existsUserAccountById(userId)) {
            throw new ApiException("No such user account was found");
        }
        UserAccount userAccount = userAccountRepository.findUserAccountById(userId);

        Issue issue = issueRepository.findIssueById(meeting.getIssueId());
        if (!issue.getNeighborhoodId().equals(userAccount.getNeighborhoodId())) {
            throw new ApiException("You can only attend meetings in your neighborhood");
        }

        if (meetingAttendanceRepository.existsMeetingAttendanceByUserIdAndMeetingId(meetingId, userId)) {
            throw new ApiException("User is already registered for this meeting");
        }
        if (meetingAttendanceRepository.countUserRegisteredAtSameTime(userId, meeting.getMeetingTime()) > 0) {
            throw new ApiException("User is already registered for another meeting at the same time");
        }
        MeetingAttendance meetingAttendance = new MeetingAttendance();
        meetingAttendance.setMeetingId(meetingId);
        meetingAttendance.setUserId(userId);
        meetingAttendance.setRegistrationDate(LocalDateTime.now());
        meetingAttendanceRepository.save(meetingAttendance);

    }

    // method to end a meeting
    public void endMeeting(Integer userId,Integer meetingId, String outcome) {
        Meeting meeting = meetingRepository.findMeetingById(meetingId);
        if (meeting == null) {
            throw new ApiException("no meeting with this id was found");
        }
        if(!userAccountRepository.existsUserAccountById(userId)) {
            throw new ApiException("No such user account was found");
        }
        if (!meeting.getUserId().equals(userId)) {
            throw new ApiException("only the user who created the meeting is allowed to end the meeting");
        }

        if (!outcome.equals("Solved") && !outcome.equals("Not Solved")) {
            throw new ApiException("Invalid outcome");
        }
        meeting.setOutcome(outcome);
        meetingRepository.save(meeting);
        if (outcome.equalsIgnoreCase("Solved")) {
            Issue issue = issueRepository.findIssueById(meeting.getIssueId());
            issue.setStatus("Resolved");
            issue.setClosedAt(LocalDateTime.now());
            issueRepository.save(issue);
        }

    }
}
