package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Neighborhood;
import com.example.capstone2.Repository.NeighborhoodRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class NeighborhoodService {
    private final NeighborhoodRepository neighborhoodRepository;

    // get all neighborhoods
    public List<Neighborhood> getAllNeighborhoods(){
        return neighborhoodRepository.findAll();
    }

    // add neighborhood
    public void addNeighborhood(Neighborhood neighborhood){
        neighborhoodRepository.save(neighborhood);
    }

    // update
    public void updateNeighborhood(Integer id,Neighborhood neighborhood){
        Neighborhood oldNeighborhood = neighborhoodRepository.findNeighborhoodById(id);
        if (oldNeighborhood == null){
            throw new ApiException("no such neighborhood was found  ");
        }
        oldNeighborhood.setCity(neighborhood.getCity());
        oldNeighborhood.setName(neighborhood.getName());
        oldNeighborhood.setLatitude(neighborhood.getLatitude());
        oldNeighborhood.setLongitude(neighborhood.getLongitude());
        neighborhoodRepository.save(oldNeighborhood);
    }

    public void deleteNeighborhood(Integer id){
        Neighborhood oldNeighborhood = neighborhoodRepository.findNeighborhoodById(id);
        if (oldNeighborhood == null){
            throw new ApiException("no such neighborhood was found  ");
        }
        neighborhoodRepository.delete(oldNeighborhood);
    }

    // method to get neighborhoods by city
    public List<Neighborhood> getAllNeighborhoodsByCity(String city){
        List<Neighborhood> neighborhoods = neighborhoodRepository.findNeighborhoodByCity(city);
        if (neighborhoods.isEmpty()){
            throw new ApiException("no neighborhoods for this city was found ");
        }
        return neighborhoods;
    }


}
