package com.example.capstone2.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Check;

import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "user id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer userId;
    @NotNull(message = "neighborhood id cannot be empty")
    @Column(columnDefinition = "int not null")
    private Integer neighborhoodId;

    @NotEmpty(message = "title cannot be empty")
    @Size(min = 6, max = 40,message = "title must be more then 6 and less than or equal to 40 char")
    @Column(columnDefinition = "varchar(40) not null")
    @Check(constraints = "CHAR_LENGTH(title) >= 6")
    private String title;

    @NotEmpty(message = "description cannot be empty")
    @Size(min = 20, max = 350,message = "description must be more then 20 and less than or equal to 350 char")
    @Column(columnDefinition = "varchar(350) not null")
    @Check(constraints = "CHAR_LENGTH(description) >= 20")
    private String description;

    @NotEmpty(message = "you must choose a category")
    @Pattern(regexp = "^(Infrastructure Issues|Public Safety|Visual Violations|Waste Management" +
            "|Environmental Concerns|Noise Complaints|Water Supply Issues" +
            "|Electricity and Utilities|Community Disturbances|Other)$")
    @Column(columnDefinition = "varchar(26) not null")
    @Check(constraints = "category IN ('Infrastructure Issues', 'Public Safety','Visual Violations'," +
            "'Waste Management','Environmental Concerns','Noise Complaints','Water Supply Issues'," +
            "'Electricity and Utilities','Community Disturbances','Other')")
    private String category;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Pattern(regexp = "^(Pending|Resolved|Overdue)$")
    @Column(columnDefinition = "varchar(8) default 'Pending'")
    private String status ="Pending";

    @NotNull(message = "creation date cannot be null")
    @Column(columnDefinition = "timestamp default current_timestamp")
    private LocalDateTime createdAt = LocalDateTime.now();

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Column(columnDefinition = "timestamp")
    private LocalDateTime closedAt ;

    @NotNull(message = "latitude cannot be null")
    @Column(columnDefinition = "double not null")
    private Double latitude;
    @NotNull(message = "longitude cannot be null")
    @Column(columnDefinition = "double not null")
    private Double longitude;

    @NotNull(message = "must choose to create meeting or not")
    @Column(columnDefinition = "boolean not null")
    private Boolean createMeeting;


}
