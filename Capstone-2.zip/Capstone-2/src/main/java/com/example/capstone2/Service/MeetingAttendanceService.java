package com.example.capstone2.Service;

import com.example.capstone2.Model.MeetingAttendance;
import com.example.capstone2.Repository.MeetingAttendanceRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class MeetingAttendanceService {
    private final MeetingAttendanceRepository meetingAttendanceRepository;

    public List<MeetingAttendance> getAllMeetingAttendance() {
        return meetingAttendanceRepository.findAll();
    }


}
