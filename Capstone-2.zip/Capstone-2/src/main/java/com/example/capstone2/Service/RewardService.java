package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.MeetingAttendance;
import com.example.capstone2.Model.Reward;
import com.example.capstone2.Repository.*;
import lombok.AllArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class RewardService {
    private final RewardRepository rewardRepository;
    private final AdminAccountRepository adminAccountRepository;
    private final IssueRepository issueRepository;
    private UserAccountRepository userAccountRepository;
    private final MeetingAttendanceRepository meetingAttendanceRepository;
    private final ProposalVoteRepository proposalVoteRepository;



    // get all reward
    public List<Reward> getAllRewards() {
        return rewardRepository.findAll();
    }

    // each user will have a reward
    public void addReward(Reward reward) {
        rewardRepository.save(reward);
    }

    public void updateReward(Integer adminId,Integer id,Reward reward) {
        if (! adminAccountRepository.existsById(adminId)) {
            throw new ApiException("Admin Account does not exist");
        }

        Reward oldReward = rewardRepository.findRewardById(id);
        if (oldReward == null) {
            throw new ApiException("Reward does not exist");
        }
        oldReward.setPoints(reward.getPoints());
        oldReward.setBadge(reward.getBadge());
        rewardRepository.save(oldReward);
    }

    public void deleteReward(Integer adminId,Integer id) {
        if (! adminAccountRepository.existsById(adminId)) {
            throw new ApiException("Admin Account does not exist");
        }
        if (!rewardRepository.existsRewardById(id)) {
            throw new ApiException("Reward does not exist");
        }
        rewardRepository.deleteById(id);
    }

//    // method to add points and update badge by user id
//    public void updateUserPoints(Integer userId){
//        Reward reward = rewardRepository.findRewardById(userId);
//        if (reward == null) {
//            throw new ApiException("Reward does not exist");
//        }
//        Integer newPoints = reward.getPoints()+ 10;
//        reward.setPoints(newPoints);
//        reward.setBadge(checkBadge(newPoints));
//        rewardRepository.save(reward);
//    }

    // method that returns the alligned badge
    public String checkBadge(Integer points) {
        if (points >= 500) {
            return "Neighborhood Hero";
        }
        if (points >= 300) {
            return "Problem Solver";
        }
        if (points >= 150) {
            return "Helper";
        }
        if (points >= 50) {
            return "Contributor";
        }
        return "Beginner";
    }

    public Reward calculateUserReward(Integer userId) {
        if(!userAccountRepository.existsById(userId)) {
            throw new ApiException("User Account does not exist");
        }
        Reward reward = rewardRepository.findRewardByUserId(userId);
        if (reward == null) {
            throw new ApiException("Reward does not exist");
        }
        Integer numberOfUserResolvedIssues = issueRepository.countIssueByStatusAndUserId("Resolved", userId);
        Integer pointsFromIssues = numberOfUserResolvedIssues * 10;


        Integer numberOfMeetingsAttended = meetingAttendanceRepository.countByUserId(userId);
        Integer pointsFromMeetings = numberOfMeetingsAttended * 5;

        Integer numberOfProposalVotes = proposalVoteRepository.countByUserId(userId);
        Integer pointsFromProposalVotes = numberOfProposalVotes * 1;

        Integer newPoints = pointsFromIssues + pointsFromMeetings + pointsFromProposalVotes;

        reward.setPoints(newPoints);
        reward.setBadge(checkBadge(newPoints));
        rewardRepository.save(reward);
        return reward;

    }

    //  method to get the leaderboards
    public List<Reward> getLeaderboard(Integer neighborhoodId) {
        List<Reward> rewards = rewardRepository.findLeaderBoards();
        for (Reward reward : rewards) {
            if (!userAccountRepository.findUserAccountById(reward.getUserId()).getNeighborhoodId().equals(neighborhoodId)) {
                rewards.remove(reward);

            }
        }
        if (rewards.isEmpty()) {
            throw new ApiException("No rewards found");
        }
        return rewards;
    }
}
