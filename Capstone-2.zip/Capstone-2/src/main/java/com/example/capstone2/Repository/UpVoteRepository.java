package com.example.capstone2.Repository;

import com.example.capstone2.Model.UpVote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UpVoteRepository extends JpaRepository<UpVote, Integer> {

    UpVote findUpVoteById(Integer id);

    Integer countUpVoteByIssueId(Integer issueId);

    Boolean existsUpVoteByUserIdAndIssueId(Integer userId, Integer issueId);
}
