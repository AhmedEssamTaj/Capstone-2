package com.example.capstone2.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpVote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotNull(message = "vote must be connected to a user")
    @Column(columnDefinition = "int not null")
    private Integer userId;
    @NotNull(message = "vote must be connected to a issue")
    @Column(columnDefinition = "int not null")
    private Integer issueId;
}
