package com.example.capstone2.ApiResponse;


public class ApiException extends RuntimeException {
    public ApiException(String message) {
        super(message);
    }
}
