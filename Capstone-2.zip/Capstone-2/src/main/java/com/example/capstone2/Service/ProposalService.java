package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.Proposal;
import com.example.capstone2.Repository.*;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@AllArgsConstructor
public class ProposalService {
    private final ProposalRepository proposalRepository;
    private final UserAccountRepository userAccountRepository;
    private final NeighborhoodRepository neighborhoodRepository;
    private final AdminAccountRepository adminAccountRepository;
    private final ProposalVoteRepository proposalVoteRepository;

    // get all proposals
    public List<Proposal> getAllProposals() {
        return proposalRepository.findAll();
    }

    // add proposal
    public void addProposal(Proposal proposal) {
        if (!userAccountRepository.existsUserAccountById(proposal.getUserId())) {
            throw new ApiException("No user with this id was found");
        }

        if (!neighborhoodRepository.existsNeighborhoodById(proposal.getNeighborhoodId())) {
            throw new ApiException("No neighborhood with this id was found");
        }
        proposalRepository.save(proposal);
    }

    // update proposal
    public void updateProposal(Integer id, Proposal proposal) {
        Proposal oldProposal = proposalRepository.findProposalById(id);
        if (oldProposal == null) {
            throw new ApiException("No proposal with this id was found");
        }
        if (!userAccountRepository.existsUserAccountById(proposal.getUserId())) {
            throw new ApiException("No user with this id was found");
        }
        if (!neighborhoodRepository.existsNeighborhoodById(proposal.getNeighborhoodId())) {
            throw new ApiException("No neighborhood with this id was found");
        }
        oldProposal.setUserId(proposal.getUserId());
        oldProposal.setNeighborhoodId(proposal.getNeighborhoodId());
        oldProposal.setTitle(proposal.getTitle());
        oldProposal.setDescription(proposal.getDescription());
        oldProposal.setCategory(proposal.getCategory());
        oldProposal.setStatus(proposal.getStatus());
        oldProposal.setLatitude(proposal.getLatitude());
        oldProposal.setLongitude(proposal.getLongitude());
        proposalRepository.save(oldProposal);

    }

    // delete a proposal
    public void deleteProposal(Integer id) {
        if (!proposalRepository.existsProposalById(id)) {
            throw new ApiException("No proposal with this id was found");
        }
        proposalRepository.deleteById(id);
    }

    // method to close a proposal if it passed its close date
    @Scheduled(fixedDelay = 60000)
    public void closeProposalVote() {
        LocalDateTime now = LocalDateTime.now();
        List<Proposal> proposalsToClose = proposalRepository.findAllByClosingDateBeforeAndIsClosedFalse(now);
        for (Proposal proposal : proposalsToClose) {
            proposal.setStatus("Closed");
            proposal.setIsClosed(true);
            proposalRepository.save(proposal);
        }
        System.out.println("Proposal closed");
    }

    // method to approve/reject a proposal
    public String proposalDecision(Integer adminId, Integer proposalId) {
        if (!adminAccountRepository.existsAdminAccountById(adminId)) {
            throw new ApiException("No admin with this id was found");
        }
        if (!proposalRepository.existsProposalById(proposalId)) {
            throw new ApiException("No proposal with this id was found");
        }

        Proposal proposal = proposalRepository.findProposalById(proposalId);

        if (!proposal.getStatus().equals("Closed")) {
            throw new ApiException("Proposal voting is not closed yet");
        }

        int inFavour = proposalVoteRepository.countProposalVoteByProposalIdAndInFavor(proposalId, true);
        int against = proposalVoteRepository.countProposalVoteByProposalIdAndInFavor(proposalId, false);

        if (inFavour == 0 && against == 0) {
            proposal.setStatus("Cancelled");
            proposalRepository.save(proposal);
            return "No votes were cast, proposal has been Cancelled";
        }


        if (inFavour == against) {
            proposal.setStatus("Tied");
            proposalRepository.save(proposal);
            return "Voting resulted in a tie, proposal status set to Tied";
        }


        if (inFavour > against) {
            proposal.setStatus("Approved");
            proposalRepository.save(proposal);
            return "Majority of voting was in favour, Proposal has been Approved";
        } else {
            proposal.setStatus("Rejected");
            proposalRepository.save(proposal);
            return "Majority of voting was not in favour, Proposal has been Rejected";
        }
    }

    // method to get getProposal By User Id
    public List<Proposal> getProposalByUserId(Integer userId) {
        List<Proposal>proposals = proposalRepository.findProposalByUserId(userId);
        if (proposals.isEmpty()) {
            throw new ApiException("user has no proposals");
        }
        return proposals;
    }
}
