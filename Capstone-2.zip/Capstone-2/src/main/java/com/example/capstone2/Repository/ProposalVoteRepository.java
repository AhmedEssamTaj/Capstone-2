package com.example.capstone2.Repository;

import com.example.capstone2.Model.ProposalVote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProposalVoteRepository extends JpaRepository<ProposalVote, Integer> {

    ProposalVote findProposalVoteById(Integer id);

    Boolean existsProposalVoteById(Integer id);

    Boolean existsProposalVoteByUserIdAndProposalId(Integer userId, Integer proposalId);

    Integer countProposalVoteByProposalIdAndInFavor(Integer proposalId, Boolean inFavor);

    Integer countByUserId(Integer userId);
}
