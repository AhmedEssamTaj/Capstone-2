package com.example.capstone2.Repository;

import com.example.capstone2.Model.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface IssueRepository extends JpaRepository<Issue, Integer> {

    Issue findIssueById(Integer id);

    Boolean existsIssueById(Integer id);


    @Query("select i from Issue i where i.status IN ('Pending', 'Overdue') and i.neighborhoodId = ?1")
    List<Issue> getAllIssueThatAreUnresolved(Integer neighborhoodId);

    // get issues that by status and before a certain date
    List<Issue> findByStatusAndCreatedAtBefore(String status, LocalDateTime date);

    // get the list of issues that are close within the user location using Haversine formula
    @Query(value = """
                SELECT i.*, 
                       (6371 * acos(cos(radians(:userLat)) * cos(radians(i.latitude)) 
                       * cos(radians(i.longitude) - radians(:userLng)) 
                       + sin(radians(:userLat)) * sin(radians(i.latitude)))) AS distance 
                FROM issue i 
                WHERE i.neighborhood_id = :neighborhoodId
                ORDER BY distance
                LIMIT :limit
            """, nativeQuery = true)
    List<Issue> findClosestIssues(Double userLat, Double userLng, Integer neighborhoodId, int limit);



    // get all the unresolved issues from the past week in a neighborhood
    @Query("select i from Issue i where i.status = 'Pending' and i.neighborhoodId = ?2 and i.createdAt >= ?1")
    List<Issue> findUrgentIssues( LocalDateTime oneWeekAgo , Integer neighborhoodId);

    // get all overdue issues within a neighborhood
    @Query("select i from Issue i where i.neighborhoodId = ?1 and i.status='Overdue'")
    List<Issue> getOverdueIssues(Integer neighborhoodId);

    // count the number of resolved issues by a user Id (for rewards)
    Integer countIssueByStatusAndUserId(String status, Integer userId);
}
