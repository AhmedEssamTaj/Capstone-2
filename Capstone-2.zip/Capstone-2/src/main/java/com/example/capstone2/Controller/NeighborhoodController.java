package com.example.capstone2.Controller;


import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Issue;
import com.example.capstone2.Model.Neighborhood;
import com.example.capstone2.Service.NeighborhoodService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.security.PublicKey;

@RestController
@RequestMapping("api/v1/neighborhood")
@AllArgsConstructor
public class NeighborhoodController {
    private NeighborhoodService neighborhoodService;

    @GetMapping("/get-all")
    public ResponseEntity getAllNeighborhoods() {
        return ResponseEntity.status(200).body(neighborhoodService.getAllNeighborhoods());
    }

    @PostMapping("/add")
    public ResponseEntity addNeighborhood(@RequestBody @Valid Neighborhood neighborhood, Errors errors) {

        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        neighborhoodService.addNeighborhood(neighborhood);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully added Neighborhood"));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity updateNeighborhood(@PathVariable Integer id,@RequestBody @Valid Neighborhood neighborhood, Errors errors) {
        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        neighborhoodService.updateNeighborhood(id, neighborhood);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully updated Neighborhood"));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteNeighborhood(@PathVariable Integer id) {
        neighborhoodService.deleteNeighborhood(id);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully deleted Neighborhood"));
    }

    // endpoint to get the list of neighborhoods by the city
    @GetMapping("/get-city/{city}")
    public ResponseEntity getNeighborhoodByCity(@PathVariable String  city) {
        return ResponseEntity.status(200).body(neighborhoodService.getAllNeighborhoodsByCity(city));
    }

}
