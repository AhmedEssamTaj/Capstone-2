package com.example.capstone2.Repository;

import com.example.capstone2.Model.Neighborhood;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NeighborhoodRepository extends JpaRepository<Neighborhood, Integer> {

    Neighborhood findNeighborhoodById(Integer id);

    Boolean existsNeighborhoodById(Integer id);

    List <Neighborhood> findNeighborhoodByCity(String city);
}
