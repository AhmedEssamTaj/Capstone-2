package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiException;
import com.example.capstone2.Model.UpVote;
import com.example.capstone2.Repository.IssueRepository;
import com.example.capstone2.Repository.UpVoteRepository;
import com.example.capstone2.Repository.UserAccountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UpVoteService {
    private final UpVoteRepository upVoteRepository;
    private final UserAccountRepository userAccountRepository;
    private final IssueRepository issueRepository;

    // get all up vote
    public List<UpVote> getAllUpVotes() {
        return upVoteRepository.findAll();
    }

    // get the number of upvote an issue has
    public Integer countUpVotes(Integer issueId) {
        if (!issueRepository.existsIssueById(issueId)) {
            throw new ApiException("No issue with this id exists");
        }
        return upVoteRepository.countUpVoteByIssueId(issueId);

    }

    // add upvote
    public void addUpVote(UpVote upVote) {
        if (!userAccountRepository.existsUserAccountById(upVote.getUserId())){
            throw new ApiException("no user with this id was found");
        }
        if (!issueRepository.existsIssueById(upVote.getIssueId())){
            throw new ApiException("no issue with this id was found");
        }
        if (upVoteRepository.existsUpVoteByUserIdAndIssueId(upVote.getUserId(), upVote.getIssueId())) {
            throw new ApiException("user already voted up");
        }
        if(issueRepository.findIssueById(upVote.getIssueId()).getStatus().equals("Resolved")){
            throw new ApiException("cannot up vote a Resolved issue");
        }
        upVoteRepository.save(upVote);
    }

    // delete upvote
    public void deleteUpVote(Integer upVoteId) {

        UpVote upVote = upVoteRepository.findUpVoteById(upVoteId);
        if (upVote == null) {
            throw new ApiException("no upvote with this id was found");
        }
        upVoteRepository.delete(upVote);
    }
}
