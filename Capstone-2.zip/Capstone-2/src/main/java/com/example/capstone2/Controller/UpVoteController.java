package com.example.capstone2.Controller;

import com.example.capstone2.ApiResponse.ApiResponse;
import com.example.capstone2.Model.Neighborhood;
import com.example.capstone2.Model.UpVote;
import com.example.capstone2.Service.UpVoteService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/up-vote")
@AllArgsConstructor
public class UpVoteController {
    private final UpVoteService upVoteService;

    @GetMapping("/get-all")
    public ResponseEntity getAllUpVotes() {
        return ResponseEntity.status(200).body(upVoteService.getAllUpVotes());
    }

    @PostMapping("/add")
    public ResponseEntity addUpVote(@RequestBody @Valid UpVote upVote, Errors errors) {

        if (errors.hasErrors()) {
            String message = errors.getFieldError().getDefaultMessage();
            return ResponseEntity.status(400).body(new ApiResponse(message));
        }
        upVoteService.addUpVote(upVote);
        return ResponseEntity.status(200).body(new ApiResponse("Successfully up voted"));
    }


    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteUpVote(@PathVariable Integer id) {
        upVoteService.deleteUpVote(id);
        return ResponseEntity.status(200).body(new ApiResponse("up voting deleted"));
    }

    // end point to get the number of up votes for an issue --- (7) ---
    @GetMapping("/count/{issueId}")
    public ResponseEntity countUpVotes(@PathVariable Integer issueId) {
        return ResponseEntity.status(200).body(upVoteService.countUpVotes(issueId));
    }
}
